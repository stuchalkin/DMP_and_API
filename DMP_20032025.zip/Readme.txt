1. Все папки кроме Update Sets должны быть размещены в файловом хранилище Loginom

2. Папки в Update Sets используются для обновления DMP (путем замены файлов), чтобы не затирать ваши настройки.

3. Мануал - https://docs.google.com/document/d/14vRadmFwvRNuR4aSn_V-qLOQTQB2O2wQB9OTJWBbbbs/edit?tab=t.0#heading=h.eb96njq3ziu2

4. Экспресс-обучение - https://enterprise-analytics.loginom.ru/